#!/usr/bin/env python

import os

# homepage creator for Minimal Kiosk Browser
# You'll need a html template (sample supplied) named template.html; look into the sample for details or modify it as you like
# for each category you'll need a text file in utf-8 format
# there are two types of categories: 'link' (contains http... links) or 'command' (contains command lines)
# the text file has to be named 'name.txt', where name is the name of the category
# you will find examples for each category
# the entries in the text file must be: name=link or name=commandline,
# where "name" will be the text displayed in your home page
# you can add your own categories here or rename existing categories:

categories = [{'name':'Services','type':'link','links':[]},
              {'name':'Internet','type':'link','links':[]},
              {'name':'Applications','type':'command','links':[]},
              {'name':'Tools','type':'command','links':[]},
              {'name':'Configuration','type':'command','links':[]}
              ]
# if a text file is missing, the category will not be used

template = u''
divider = u' &nbsp;&nbsp;&nbsp;&nbsp; '

pwd = os.path.dirname( os.path.abspath(__file__) )
os.chdir(pwd)
homedir = os.path.expanduser('~')

if os.path.exists('template.html'):
    f = file('template.html','rb')
    template = f.read().decode('utf-8')
    f.close()

for cat in categories:

    if os.path.exists(cat['name']+'.txt'):
        f = file(cat['name']+'.txt','rb')
        text = f.read().decode('utf-8')
        f.close()
        tl = text.split('\n')
        for t in tl:
            if not t or t.startswith('#'):
                continue
            tx = t.split('=')
            if len(tx) == 2:
                name = tx[0].strip()
                link =  tx[1].strip()
                if cat['type'] == 'link':
                    cat['links'].append('<a href="'+link+'">'+name+'</a>')
                elif cat['type'] == 'command':
                    cat['links'].append('<a href="file:///homepage.html?cmd='+link.replace(' ','%20')+'">'+name+'</a>')
if template:                    
    content = u''
    for cat in categories:
        if cat['links']:
            content += u'<table width="100%" border="0"><tr><th>' + cat['name'] + '</th></tr><tr><td>\n'
            content += divider.join(cat['links'])
            content += u'\n</td></tr></table>\n'

    page = template.replace('$$content$$',content)
    if homedir != '/home/pi':
        page = page.replace('/home/pi',homedir)
    path = homedir + os.sep + 'homepage.html'
    if os.path.exists(path):
        count = 0
        while os.path.exists(path+'.'+str(count)):
            count += 1
        os.rename(path,path+'.'+str(count))
    f = file(path,'wb')
    f.write(page.encode('utf-8'))
    f.close()
    print 'created homepage.html'
else:
    print 'No template.html found. Could not create homepage.html.'
